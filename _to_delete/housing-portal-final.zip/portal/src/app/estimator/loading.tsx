import PageLoading from "@/components/PageLoading";

export default function Loading() {
  return <PageLoading label="Loading Property Value Estimator" />;
}
